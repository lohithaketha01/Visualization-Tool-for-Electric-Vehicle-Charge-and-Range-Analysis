# 1. Data Collection & Extraction from Database

## Objective
Identify, connect to, and extract raw EV charging and range/telemetry data
from the source database so it can be prepared and visualized in later
stages.

## Data Sources (typical for this project)
- **EV Telemetry table:** vehicle ID, timestamp, battery %, odometer, speed,
  ambient temperature, distance driven per trip
- **Charging Sessions table:** session ID, vehicle ID, station ID, start
  time, end time, energy delivered (kWh), charge level (AC/DC, kW rating),
  cost
- **Vehicle Master table:** vehicle ID, model, battery capacity (kWh), rated
  range, purchase date
- **Charging Station Master table:** station ID, location, connector type,
  max power rating

## Step-by-Step Procedure

### Step 1: Confirm Data Source & Access
1. Identify the database engine (e.g., SQL Server, MySQL, PostgreSQL).
2. Obtain read-only credentials/connection string from the DBA or admin.
3. Confirm required tables/views exist and identify primary/foreign keys
   linking Vehicle ↔ Charging Sessions ↔ Telemetry.

### Step 2: Establish Connection
- **Via SQL client:** Connect using SSMS / MySQL Workbench / pgAdmin to
  explore schema.
- **Via Python:**
  ```python
  import sqlalchemy as sa
  import pandas as pd

  engine = sa.create_engine("mssql+pyodbc://user:password@server/EV_DB?driver=ODBC+Driver+17+for+SQL+Server")
  query = "SELECT * FROM ChargingSessions WHERE start_time >= '2024-01-01'"
  df_charging = pd.read_sql(query, engine)
  ```
- **Via BI tool (Tableau/Power BI):** Use native "Connect to Database"
  connector, select tables, and either import or set up a live connection.

### Step 3: Extract Required Tables
Write targeted SQL queries per table rather than pulling entire tables
where possible, to reduce load:
```sql
SELECT VehicleID, Timestamp, BatteryPercent, Odometer, AmbientTempC
FROM VehicleTelemetry
WHERE Timestamp BETWEEN @start_date AND @end_date;

SELECT SessionID, VehicleID, StationID, StartTime, EndTime,
       EnergyDeliveredKWh, ChargeLevel, Cost
FROM ChargingSessions
WHERE StartTime BETWEEN @start_date AND @end_date;
```

### Step 4: Export/Stage the Data
- Save extracted tables as staging files (CSV/Parquet) or a staging schema
  in the database (`stg_telemetry`, `stg_charging_sessions`) so the
  extraction step is repeatable and doesn't hit production repeatedly.

### Step 5: Document Extraction Metadata
Record for each extract:
- Source table/query used
- Date range extracted
- Row count extracted
- Extraction timestamp
- Any filters applied

## Validation Checks
- [ ] Row counts match expected volume (compare against source table counts)
- [ ] No duplicate primary keys in extracted data
- [ ] Date ranges are complete (no unexpected gaps)
- [ ] Foreign keys (VehicleID, StationID) exist in respective master tables

## Deliverables of This Stage
- Raw staged extracts (CSV/Parquet or staging tables)
- Extraction log documenting source, filters, and row counts
- Data dictionary of extracted fields (name, type, description, source table)

## Tools Used
SQL (T-SQL/MySQL/PostgreSQL), Python (pandas, SQLAlchemy) or BI tool native
connectors, database client (SSMS/DBeaver/pgAdmin).
