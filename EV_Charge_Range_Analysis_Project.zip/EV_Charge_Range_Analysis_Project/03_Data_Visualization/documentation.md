# 3. Data Visualization

## Objective
Design and build individual charts/visuals that answer specific analytical
questions about EV charging behavior and range performance, before
combining them into dashboards.

## Key Analytical Questions to Visualize
1. How does battery range change over time / with usage?
2. What are peak charging times and durations?
3. How does charge rate vary by charge type (Level 1/2/DC Fast)?
4. Which stations/locations are used most, and how long are sessions there?
5. How does range efficiency vary by vehicle model, temperature, or driving
   pattern?
6. What is the cost trend of charging over time?

## Step-by-Step Procedure

### Step 1: Select Chart Types per Question

| Question | Recommended Chart |
|---|---|
| Range vs. time/usage | Line chart (Range % over trip distance or days) |
| Charging duration distribution | Histogram / Box plot |
| Charge rate by charge type | Bar chart / Grouped bar chart |
| Station usage frequency | Bar chart ranked by session count; Map (geo) for station locations |
| Range efficiency by model | Box plot or bar chart with error bars |
| Efficiency vs. temperature | Scatter plot with trend line |
| Cost trend over time | Line/area chart, monthly aggregation |
| Charging pattern by hour/day | Heat map (Hour of Day x Day of Week) |

### Step 2: Build Visuals (Tableau example workflow)
1. Connect the visualization tool to the prepared datasets from Stage 2.
2. Create calculated fields directly in-tool if needed (e.g., moving
   averages, rolling range efficiency).
3. Build each chart as an individual worksheet:
   - Drag dimensions (VehicleModel, StationID, Date) to Columns/Rows.
   - Drag measures (RangeAddedKm, ChargeDurationMin, Cost) to appropriate
     shelves (Rows, Color, Size, Label).
   - Apply filters (date range, vehicle model, station) as needed.
4. Format each chart: clear titles, axis labels, tooltips with contextual
   detail, consistent color palette across the project (e.g., one color per
   charge type).

### Step 3: Apply Consistent Design Standards
- Use a single, consistent color scheme (e.g., blue = AC charging, orange =
  DC fast charging).
- Label axes with units (kWh, km, minutes).
- Add tooltips showing exact values on hover.
- Keep font/style consistent with the Dashboard stage.

### Step 4: Validate Each Visual
- Cross-check a few data points on each chart against the source data.
- Confirm filters/parameters work correctly and update the chart as
  expected.

## Deliverables of This Stage
- Individual worksheets/charts (one per analytical question above)
- Style guide (colors, fonts, chart conventions) to keep the Dashboard and
  Story stages consistent
- Screenshot exports of each finished chart for documentation/demo use

## Tools Used
Tableau Desktop / Power BI Desktop (worksheet/visual layer), or
matplotlib/plotly/seaborn if a code-based visualization approach is used.
