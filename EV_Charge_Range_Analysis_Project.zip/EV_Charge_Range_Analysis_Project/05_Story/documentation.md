# 5. Story

## Objective
Turn the dashboards and charts into a guided narrative ("Story") that walks
a stakeholder through the key findings in a logical sequence — useful for
presentations, executive readouts, and the demonstration video.

## Step-by-Step Procedure

### Step 1: Define the Narrative Arc
Decide on the sequence of insights you want to communicate. Suggested
storyline for this project:
1. **Context / Scope** — What data are we looking at? (date range, number
   of vehicles, number of stations)
2. **Charging Behavior** — When and how do people charge? (peak hours,
   charge type mix, average duration)
3. **Range Performance** — How does range hold up in practice vs. rated
   range? What affects it (temperature, driving style)?
4. **Cost & Efficiency** — What's the cost per km, and how does it compare
   across charge types/stations?
5. **Key Takeaways / Recommendations** — Summarize actionable insights
   (e.g., "DC fast charging is 3x more expensive per kWh but used only 10%
   of the time," or "range drops 15% in sub-zero temperatures").

### Step 2: Build Story Points
1. Create a new Story in the visualization tool (Tableau "Story" feature,
   or a sequence of Power BI report pages / PowerPoint export).
2. For each narrative step above, add a story point that pulls in the
   relevant dashboard or chart from Stage 3/4.
3. Use the "caption" or text box under each story point to add a one-line
   takeaway (not just a chart title — the actual insight, e.g. "Charging
   sessions peak between 6–8 PM as vehicles return home").

### Step 3: Highlight Key Data Points
On each story point, use annotations, highlighted marks/colors, or callout
text boxes to draw attention to the specific number or trend that supports
the narrative (e.g., circle the peak bar in a bar chart with a callout
"38% of sessions").

### Step 4: Sequence and Transitions
- Order story points so each one logically follows from the last.
- Keep each story point focused on one key idea — avoid cramming multiple
  unrelated insights into a single point.
- Add a short intro story point (title + scope) and a closing story point
  (key takeaways/recommendations).

### Step 5: Review Flow End-to-End
- Present the story to yourself/a peer as if it were the final stakeholder
  readout — confirm it reads coherently top to bottom without needing
  additional verbal explanation.

## Deliverables of This Stage
- Completed Story (Tableau Story / Power BI narrative pages / exported
  slide deck) with captions and callouts
- A short written script (bullet points) of the narrative, to be reused
  when recording the demonstration video in Stage 8

## Tools Used
Tableau Desktop (Story feature) or Power BI (Report pages + "Bookmarks" for
narrative navigation) / PowerPoint for a slide-based alternative.
