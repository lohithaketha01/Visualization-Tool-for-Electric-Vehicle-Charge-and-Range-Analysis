# 6. Performance Testing

## Objective
Verify the dashboard/story loads quickly, handles the expected data volume,
and remains responsive under realistic usage, before it is integrated into
the web.

## Step-by-Step Procedure

### Step 1: Define Performance Targets
Set clear, testable targets, e.g.:
- Dashboard initial load time ≤ 5 seconds
- Filter/interaction response time ≤ 2 seconds
- Supports at least [N] concurrent users (if server/web-hosted) without
  degradation
- Works correctly with the full production data volume (not just a sample)

### Step 2: Test with Full-Scale Data
- Point the dashboard at the complete prepared dataset (not a small test
  sample) to confirm performance holds at real volume.
- If using an extract (vs. live connection), test with the extract refreshed
  to current data size.

### Step 3: Use Built-In Performance Diagnostics
- **Tableau:** Use the *Performance Recorder* (Help → Settings and
  Performance → Start Performance Recording) to capture query times,
  rendering times, and identify slow worksheets/calculations.
- **Power BI:** Use *Performance Analyzer* (View tab) to record and inspect
  visual load times, DAX query duration, and rendering duration.

### Step 4: Identify and Fix Bottlenecks
Common fixes if targets aren't met:
- Replace complex row-level calculated fields with pre-aggregated fields
  computed back in Stage 2 (Data Preparation).
- Reduce the number of marks/data points rendered (aggregate dates to
  week/month instead of raw timestamp where appropriate).
- Use extracts instead of live database connections where real-time data
  isn't required.
- Add indexes on join/filter columns at the database level if using a live
  connection.
- Limit the number of filters/quick-filters that trigger full dashboard
  recalculation; use context filters or actions instead.

### Step 5: Load / Concurrency Testing (if web-hosted)
- If the dashboard will be published to a server (Tableau Server/Public,
  Power BI Service) or embedded on a website, simulate multiple simultaneous
  users opening/interacting with it and monitor server response times.

### Step 6: Re-test After Fixes
- Repeat Steps 3–5 after applying optimizations and confirm targets from
  Step 1 are now met.
- Document before/after load times to demonstrate improvement.

## Validation Checks
- [ ] Load time targets met with full production data volume
- [ ] Filter/interaction response time targets met
- [ ] No errors or timeouts under expected concurrent usage
- [ ] Performance test results documented with before/after metrics

## Deliverables of This Stage
- Performance test report (targets vs. actual results, before/after
  optimization)
- List of optimizations applied
- Sign-off that the dashboard is ready for web integration

## Tools Used
Tableau Performance Recorder, Power BI Performance Analyzer, browser dev
tools (Network tab) if web-embedded.
