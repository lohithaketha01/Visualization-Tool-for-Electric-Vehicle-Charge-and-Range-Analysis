Place your final recorded walkthrough video (.mp4) in this folder.
