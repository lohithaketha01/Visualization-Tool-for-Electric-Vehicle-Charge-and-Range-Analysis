Place your dashboard/story/report screenshots (.png/.jpg) in this folder.
