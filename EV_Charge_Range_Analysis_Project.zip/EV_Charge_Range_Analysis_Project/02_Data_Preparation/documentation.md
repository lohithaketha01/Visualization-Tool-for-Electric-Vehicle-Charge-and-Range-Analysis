# 2. Data Preparation

## Objective
Clean, transform, and enrich the raw extracted data so it is analysis-ready:
consistent formats, no duplicates/nulls issues, correct data types, and new
calculated fields needed for charge and range analysis.

## Step-by-Step Procedure

### Step 1: Load Staged Data
Load the CSV/Parquet extracts (or staging tables) from Stage 1 into your
prep tool (Python/pandas, Tableau Prep, Power Query, or SQL).

### Step 2: Data Cleaning
1. **Handle missing values**
   - Drop or impute missing `BatteryPercent`, `Odometer` readings using
     forward-fill per vehicle/time-series or interpolation.
2. **Remove duplicates**
   - De-duplicate on `SessionID` and `(VehicleID, Timestamp)`.
3. **Correct data types**
   - Ensure timestamps are proper datetime, energy/cost fields are numeric,
     categorical fields (ChargeLevel, ConnectorType) are strings/categories.
4. **Outlier handling**
   - Flag/remove impossible values (e.g., BatteryPercent > 100 or < 0,
     negative EnergyDeliveredKWh, session duration ≤ 0).

### Step 3: Data Transformation & Feature Engineering
Create the calculated fields the visualization stage will need:

| New Field | Formula / Logic |
|---|---|
| `ChargeDurationMin` | `EndTime - StartTime` (in minutes) |
| `ChargeRateKW` | `EnergyDeliveredKWh / (ChargeDurationMin / 60)` |
| `RangeAddedKm` | `EnergyDeliveredKWh * EfficiencyKmPerKWh` (from vehicle master) |
| `SOC_Delta` | `EndBatteryPercent - StartBatteryPercent` |
| `EstimatedRangeRemaining` | `BatteryPercent% * RatedRangeKm` |
| `TripDistance` | `Odometer_end - Odometer_start` per trip |
| `RangeEfficiency` | `TripDistance / EnergyConsumedKWh` |
| `DayOfWeek`, `HourOfDay` | Derived from Timestamp, for usage-pattern analysis |
| `ChargeType` | Bucketed as Level 1 / Level 2 / DC Fast based on ChargeRateKW |

### Step 4: Join & Merge Datasets
- Join `ChargingSessions` with `VehicleMaster` on `VehicleID` to bring in
  battery capacity and rated range.
- Join `ChargingSessions` with `StationMaster` on `StationID` for location
  and connector type.
- Merge telemetry with trip logs to compute per-trip range consumption.

### Step 5: Aggregate Where Needed
Pre-aggregate tables for dashboard performance, e.g.:
- Daily/weekly charging summary per vehicle
- Monthly average range efficiency per model
- Station utilization (sessions per day, average session duration)

### Step 6: Export Prepared Datasets
Save cleaned/transformed tables as the "analysis-ready" layer (e.g.
`fact_charging_sessions_clean.csv`, `fact_trips_clean.csv`,
`dim_vehicle.csv`, `dim_station.csv`) ready to be imported into the
visualization tool.

## Validation Checks
- [ ] No nulls remain in key analytical fields
- [ ] No negative or impossible values in energy/duration/range fields
- [ ] Row counts reconcile with Stage 1 extract counts (minus intentionally
      removed bad rows — document how many and why)
- [ ] Spot-check calculated fields against a manual sample calculation

## Deliverables of This Stage
- Cleaned, transformed "analysis-ready" data files/tables
- Data cleaning log (rows removed/modified and why)
- Data dictionary update including all newly engineered fields

## Tools Used
Python (pandas, numpy), SQL, Tableau Prep Builder, or Power Query (Excel/Power BI).
