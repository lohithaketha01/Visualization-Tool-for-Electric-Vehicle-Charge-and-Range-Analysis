# 4. Dashboard

## Objective
Combine the individual visuals from Stage 3 into one or more interactive
dashboards that let stakeholders explore EV charging and range data
holistically, with filtering and drill-down capability.

## Step-by-Step Procedure

### Step 1: Plan Dashboard Layout
Decide how many dashboards are needed and their purpose. Suggested split:
1. **Charging Overview Dashboard** — session volume, duration, cost,
   charge-type mix, station usage.
2. **Range & Efficiency Dashboard** — range consumption trends, efficiency
   by model, impact of temperature/driving pattern.
3. **Executive Summary Dashboard** — top-line KPIs for quick review (total
   sessions, average range per charge, total energy delivered, cost per km).

### Step 2: Assemble the Dashboard
1. Create a new dashboard canvas sized appropriately (e.g., 1366x768 for
   desktop, or responsive/"Automatic" sizing for multi-device use).
2. Drag the relevant worksheets (charts) from Stage 3 onto the canvas.
3. Arrange using a grid/container layout: KPIs/summary cards at top,
   trend charts in the middle, detail tables/breakdowns at the bottom.

### Step 3: Add Interactivity
- **Filters:** Date range, vehicle model, station, charge type — applied
  globally across all charts on the dashboard ("Apply to all worksheets
  using this data source").
- **Actions:** Click on a station in a bar chart to filter the map and
  detail table to that station (dashboard actions / drill-through).
- **Parameters:** Let users toggle between metrics (e.g., switch a chart
  between "kWh delivered" and "Cost ($)").

### Step 4: Add KPI Summary Cards
Highlight key numbers at a glance, e.g.:
- Total Charging Sessions
- Total Energy Delivered (kWh)
- Average Charge Duration
- Average Range Added per Session
- Average Cost per Charging Session

### Step 5: Format for Clarity
- Consistent color palette from the Style Guide (Stage 3).
- Clear section headers/titles.
- Legends placed consistently (e.g., bottom or right of dashboard).
- Test at target screen resolution / device.

### Step 6: Review & Iterate
- Walk through the dashboard as if you were the end user answering the key
  analytical questions from Stage 3. Confirm every question can be answered
  without leaving the dashboard.
- Get informal feedback from a peer/stakeholder before finalizing.

## Validation Checks
- [ ] All filters affect all relevant charts correctly
- [ ] KPI cards match underlying detail-level totals
- [ ] Dashboard loads without errors, no broken/missing visuals
- [ ] Works at intended screen size / device (desktop and, if required, tablet)

## Deliverables of This Stage
- Finalized interactive dashboard(s) (.twbx / .pbix or equivalent)
- Screenshot exports for documentation and the demonstration video
- Short written description of what each dashboard shows and how to use it

## Tools Used
Tableau Desktop (Dashboard tab) or Power BI Desktop (Report canvas).
