# 7. Web Integration

## Objective
Publish and embed the finished dashboard/story into a website so
stakeholders can access it directly through a browser without needing the
authoring tool installed.

## Step-by-Step Procedure

### Step 1: Choose a Publishing/Hosting Target
Options depending on the tool used:
- **Tableau:** Tableau Server, Tableau Cloud, or Tableau Public (for public,
  non-sensitive data).
- **Power BI:** Power BI Service (publish report), with "Publish to web" or
  "Embed in a website/portal" options, or Power BI Embedded for app
  integration.

### Step 2: Publish the Dashboard/Story
1. In the authoring tool, sign in to the target server/service.
2. Publish the workbook/report (File → Publish to Server/Service).
3. Set data source refresh schedule (e.g., nightly) so the published
   version stays current with the underlying database from Stage 1.
4. Configure access permissions (who can view/edit).

### Step 3: Get the Embed Code
- **Tableau:** Use *Share* → *Embed Code*, which generates an `<iframe>` or
  JavaScript API snippet.
- **Power BI:** Use *File → Embed report → Website or portal*, which
  generates an `<iframe>` snippet.

Example embed pattern:
```html
<div class="dashboard-container">
  <iframe
    src="https://your-server/views/EVChargeRangeAnalysis/Overview?:embed=y"
    width="100%"
    height="800"
    frameborder="0">
  </iframe>
</div>
```

### Step 4: Integrate into the Website
1. Create or open the target web page (plain HTML page, CMS, or internal
   portal).
2. Insert the embed snippet into the page body where the dashboard should
   appear.
3. Wrap it in a responsive container (CSS) so it resizes correctly on
   different screen sizes:
   ```css
   .dashboard-container {
     position: relative;
     width: 100%;
     max-width: 1400px;
     margin: 0 auto;
   }
   .dashboard-container iframe {
     width: 100%;
     min-height: 700px;
     border: none;
   }
   ```
4. Add supporting page content: a short intro paragraph, navigation links
   between the Overview, Range & Efficiency, and Story views if published
   as separate pages/tabs.

### Step 5: Authentication & Security (if required)
- If the data is sensitive, ensure the embed requires login (Tableau
  Server/Power BI Service authentication) rather than being publicly
  accessible.
- Use trusted authentication tickets (Tableau) or Azure AD embedding (Power
  BI) for seamless single-sign-on if embedding inside an internal portal.

### Step 6: Test the Embedded Version
- Open the web page in multiple browsers (Chrome, Edge, Firefox) and
  device sizes (desktop, tablet).
- Confirm filters/interactivity work the same as in the desktop authoring
  tool.
- Confirm the data refresh schedule is updating the live web version as
  expected.

## Validation Checks
- [ ] Dashboard renders correctly and is fully interactive on the website
- [ ] Data refresh schedule confirmed working (published version matches
      latest data)
- [ ] Access control correctly restricts/allows the intended audience
- [ ] Cross-browser and responsive-layout check passed

## Deliverables of This Stage
- Live, embedded dashboard/story accessible via a web URL
- Web page source (HTML/CSS snippet) used for the embed
- Access/permissions documentation

## Tools Used
Tableau Server/Cloud/Public, Power BI Service, HTML/CSS, and the host
website/CMS platform.
